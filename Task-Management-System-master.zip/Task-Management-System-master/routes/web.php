<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\LoginController;
use App\Http\Controllers\DashboardController;
use App\Models\Notification;
use Illuminate\Support\Facades\Auth;
use App\Http\Controllers\NotificationController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return redirect('/login');
});
Route::get('/notifications', function () {
    return response()->json(Notification::where('user_id', Auth::id())->where('is_read', false)->get());
})->middleware('auth');
Route::post('/notifications/markAsReadSingle', function (Request $request) {
    $notification = auth()->user()->notifications()->find($request->id);
    
    if ($notification) {
        $notification->markAsRead();
        return response()->json(['success' => true]);
    }

    return response()->json(['success' => false]);
})->name('notifications.markAsReadSingle');


Route::get('/dashboard', function () {
    return view('dashboard'); // Ensure you have a 'dashboard.blade.php' view file
})->name('dashboard');



Route::get('/login', [LoginController::class, 'showLoginPage']);
Route::get('/dashboard', [UserController::class, 'index'])->name('dashboard');
Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard');


Route::get('/dashboard', [DashboardController::class, 'showDashboard'])->middleware('auth:sanctum');
Route::get('/users', [DashboardController::class, 'showUsers'])->middleware('auth:sanctum');
Route::get('/tasks', [DashboardController::class, 'showTasks']);
Route::get('/notifications', [NotificationController::class, 'getNotifications']);
Route::post('/notifications/read', [NotificationController::class, 'markAsRead']);
Route::get('/notifications', [NotificationController::class, 'getNotifications'])->name('notifications.get');