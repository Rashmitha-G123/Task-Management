<?php

namespace App\Notifications;

use Illuminate\Bus\Queueable;
use Illuminate\Notifications\Notification;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Messages\DatabaseMessage;

class TaskUpdateNotification extends Notification
{
    use Queueable;

    private $task;
    private $message;

    public function __construct($task, $message)
    {
        $this->task = $task;
        $this->message = $message;
    }

    public function via($notifiable)
    {
        return ['database']; // Stores in database
    }

    public function toDatabase($notifiable)
    {
        return [
            'task_id' => $this->task->id,
            'title' => $this->task->title,
            'message' => $this->message,
        ];
    }
}
