<?php

namespace App\Http\Controllers;

use App\Models\Task;
use App\Models\UserTask;
use App\Models\User;
use App\Models\Notification; // ✅ Correct Model
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Auth;
use App\Notifications\TaskUpdateNotification;


class TaskController extends Controller
{
    public function store(Request $request)
    {
        Log::info('Received data:', $request->all());

        // Validation logic
        $request->validate([
            'title' => 'required|string|max:255',
            'description' => 'required|string',
            'assigned_to' => 'required_if:role,admin|integer',
            'priority' => 'required|string',
            'status' => 'required|string',
            'role' => 'required|string', // Add this line for role validation
        ]);

        // Determine if the request is for an admin or user task
        $role = $request->input('role');
        $task = $role === 'admin' ? new Task() : new UserTask(); // Use the respective model

        $task->title = $request->input('title');
        $task->description = $request->input('description');
        $task->priority = $request->input('priority');
        $task->status = $request->input('status');
        $task->created_by = Auth::id(); // ✅ Use Auth instead of raw input

        // For admins, assign to the specified user
        if ($role === 'admin') {
            $task->assigned_to = $request->input('assigned_to');
        } else {
            // For users, assign the task to themselves
            $task->assigned_to = Auth::id();
        }

        $task->save();

        // ✅ Save Notification After Task is Created
        Notification::create([
            'user_id' => $task->assigned_to,
            'message' => "New task assigned: {$task->title}",
            'is_read' => false,
        ]);

        return response()->json(['message' => 'Task created successfully!'], 201);
    }

    public function update(Request $request, $id)
    {
        // Find the task by ID
        $task = Task::findOrFail($id);

        // Update fields with new values or keep old ones if not provided
        $task->title = $request->input('title', $task->title);
        $task->description = $request->input('description', $task->description);
        $task->status = $request->input('status', $task->status);
        $task->priority = $request->input('priority', $task->priority);
        $task->assigned_to = $request->input('assigned_to', $task->assigned_to);

        // Save updated task
        $task->save();

        // ✅ Save Notification After Task is Updated
        Notification::create([
            'user_id' => $task->assigned_to,
            'message' => "Task '{$task->title}' has been updated.",
            'is_read' => false,
        ]);

        return response()->json([
            'success' => true,
            'message' => 'Task updated successfully',
            'task' => $task
        ]);
        $user = User::find($assigned_to);
$user->notify(new TaskNotification("Task '{$task->title}' has been updated."));

    }

    public function assignTask(Request $request)
    {
        $task = new Task();
        $task->title = $request->title;
        $task->description = $request->description;
        $task->assigned_to = $request->assigned_to;
        $task->status = 'Pending';
        $task->save();

        // ✅ Save Notification After Task is Assigned
        Notification::create([
            'user_id' => $task->assigned_to,
            'message' => "A new task '{$task->title}' has been assigned to you.",
            'is_read' => false
        ]);
        $user->notify(new TaskNotification("New task assigned: {$task->title}"));

        return redirect()->back()->with('success', 'Task assigned successfully!');
    }
}
