<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class NotificationController extends Controller
{
    public function getNotifications()
{
    $notifications = auth()->user()->notifications()->whereNull('read_at')->get();
    return response()->json($notifications);
}
public function markAsRead()
{
    auth()->user()->unreadNotifications->markAsRead();
    return response()->json(['success' => true]);
}


}
