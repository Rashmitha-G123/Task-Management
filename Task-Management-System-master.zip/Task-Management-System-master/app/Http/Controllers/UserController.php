<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Task;
use App\Models\User;
use App\Models\UserTask;

class UserController extends Controller
{
     // View tasks for the logged-in user
     public function viewTasks(Request $request) {
        $tasks = Task::where('user_id', $request->user()->id)->get();
        return response()->json($tasks);
    }

    // Update task status
    public function updateTaskStatus(Request $request, $id) {
        $task = Task::findOrFail($id);
        $task->update(['status' => $request->status]);
        return response()->json(['message' => 'Task status updated successfully']);
    }

    public function getStatisticsUser($id)
{
    // Fetch tasks for the specific user
    $totalTasks = Task::where('assigned_to', $id)->count();
    $completedTasks = Task::where('assigned_to', $id)->where('status', 'completed')->count();
    $totalUsers = User::count(); // This still counts all users

    return response()->json([
        'total_tasks' => $totalTasks,
        'completed_tasks' => $completedTasks,
        'total_users' => $totalUsers,
    ]);
}



    public function getTaskUser($id)
    {
        $userId = $id; // Get the logged-in user's ID
    
        // Fetch tasks assigned to the user with associated user details
        $tasks = Task::with(['assignedTo:id,name', 'createdBy:id,name'])
                    ->where('assigned_to', $userId)
                    ->get();

        return response()->json([
            'message' => 'Data fetched successfully',
            'data' => $tasks
        ]);
    }

    public function getTaskById($id){
        $user = Task::findOrFail($id);
        return response()->json(['message' => 'User fetched successfully', 'data'=> $user]);
    }
    public function index() {
        $totalUsers = User::count();
        $totalTasks = Task::count();
        $completedTasks = Task::where('status', 'completed')->count();
    
        return view('dashboard', compact('totalUsers', 'totalTasks', 'completedTasks'));
    }
    
}
