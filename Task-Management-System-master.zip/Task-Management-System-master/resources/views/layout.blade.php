<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>@yield('title', 'Admin Dashboard')</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="stylesheet" href="{{ asset('css/tasks.css') }}">
    <style>
        /* Global Styles */
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background-color: #fff;
            padding: 20px 30px;
            border-radius: 8px;
            box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
        }

        .header-left h1 {
            font-size: 24px;
            margin: 0;
            font-weight: bold;
            color: #333;
        }

        .header-left p {
            font-size: 14px;
            color: #777;
            margin: 5px 0 0 0;
        }

        .header-right {
            display: flex;
            align-items: center;
        }

        .header-right img {
            margin-left: 20px;
            width: 40px;
            height: 40px;
            object-fit: contain;
        }

        .profile-icon {
            border-radius: 50%;
            width: 50px;
            height: 50px;
        }

        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background-color: #f5f5f5;
        }

        .container {
            display: flex;
            flex-wrap: wrap;
        }

        /* Sidebar Styles */
        .sidebar {
            width: 220px;
            background-color: #fff;
            border-right: 1px solid #ddd;
            min-height: 100vh;
            padding: 20px;
            box-sizing: border-box;
        }

        .sidebar h2 {
            text-align: center;
            margin-bottom: 20px;
        }

        .sidebar ul {
            list-style: none;
            padding: 0;
        }

        .sidebar ul li {
            margin-bottom: 15px;
        }

        .sidebar ul li a {
            text-decoration: none;
            font-size: 16px;
            color: #333;
            display: flex;
            align-items: center;
        }

        .sidebar ul li a i {
            margin-right: 10px;
        }

        /* Main Content */
        .main-content {
            flex-grow: 1;
            padding: 40px;
        }

        .main-content h1 {
            font-size: 24px;
            margin-bottom: 30px;
        }

        .stats-cards {
            display: flex;
            justify-content: space-between;
            margin-bottom: 40px;
            flex-wrap: wrap;
        }

        .card {
            flex: 1 1 25%; /* This allows the cards to adjust width dynamically */
            margin: 10px;
            padding: 20px;
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            display: flex;
            align-items: center;
            justify-content: space-between;
        }

        .card-content {
            text-align: left;
        }

        .card h3 {
            margin: 0;
            font-size: 18px;
            margin-bottom: 10px;
        }

        .card span {
            font-size: 36px;
            color: #333;
        }

        .card img {
            width: 50px; /* Adjust the width as needed */
            height: 50px; /* Adjust the height as needed */
            object-fit: contain;
        }

        /* Notification */
        .notification {
            position: absolute;
            top: 10px;
            right: 20px;
        }

        .notification .badge {
            background-color: #ffbe0b;
            color: white;
            padding: 10px 12px;
            border-radius: 50%;
        }
        .profile-dropdown {
    position: relative;
    display: inline-block;
}

.profile-icon {
    width: 40px;
    height: 40px;
    border-radius: 50%;
    cursor: pointer;
}

.dropdown-content {
    display: none;  /* Initially hidden */
    position: absolute;
    right: 0;
    background-color: white;
    min-width: 150px;
    box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.2);
    z-index: 1000;
    border-radius: 5px;
    overflow: hidden;
}

.dropdown-content a {
    display: block;
    padding: 10px;
    text-decoration: none;
    color: black;
    transition: 0.3s;
}

.dropdown-content a:hover {
    background-color: #f1f1f1;
}

        /* Responsive Styles */
        @media (max-width: 1200px) {
            .card {
                width: 30%;
            }
        }

        @media (max-width: 992px) {
            .card {
                width: 45%;
            }
        }

        @media (max-width: 768px) {
            .container {
                flex-direction: column;
            }

            .sidebar {
                width: 100%;
                border-right: none;
                border-bottom: 1px solid #ddd;
            }

            .main-content {
                padding: 20px;
            }

            .header {
                flex-direction: column;
                align-items: flex-start;
            }

            .header-right {
                margin-top: 10px;
            }

            .stats-cards {
                flex-direction: column;
            }

            .card {
                width: 100%;
                margin-bottom: 20px;
            }
        }

        @media (max-width: 576px) {
            .header-left h1 {
                font-size: 20px;
            }

            .header-left p {
                font-size: 12px;
            }

            .card h3 {
                font-size: 16px;
            }

            .card span {
                font-size: 28px;
            }

            .header-right img {
                width: 30px;
                height: 30px;
            }
        }

        @media (max-width: 400px) {
            .header-left h1 {
                font-size: 18px;
            }

            .header-left p {
                font-size: 10px;
            }

            .card h3 {
                font-size: 14px;
            }

            .card span {
                font-size: 24px;
            }

            .header-right img {
                width: 25px;
                height: 25px;
            }
        }
        .notification-container {
    position: relative;
    display: inline-block;
    cursor: pointer;
}

.notification-icon {
    width: 30px;
}

.notification-badge {
    position: absolute;
    top: -5px;
    right: -5px;
    background: red;
    color: white;
    border-radius: 50%;
    padding: 5px 8px;
    font-size: 12px;
    display: none; /* Initially hidden */
}

.dropdown-content {
    display: none;
    position: absolute;
    right: 0;
    background: white;
    box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
    width: 250px;
    z-index: 10;
    border-radius: 5px;
    padding: 10px;
}

.dropdown-header {
    font-weight: bold;
    padding-bottom: 5px;
    border-bottom: 1px solid #ccc;
}

.notification-container {
    position: relative;
    display: inline-block;
    cursor: pointer;
}

.notification-icon {
    width: 40px; /* Bell size */
    height: 40px; /* Bell size */
    font-size: 30px; /* Bell icon size */
}

.notification-badge {
    position: absolute;
    top: -5px;
    right: -5px;
    background: red; /* Red background for the badge */
    color: white; /* White text */
    border-radius: 50%; /* Make it round */
    padding: 5px 10px; /* Adjust padding for the badge */
    font-size: 12px; /* Badge text size */
    display: none; /* Initially hidden */
    min-width: 18px; /* Ensure the badge is always round */
    text-align: center; /* Center the number inside the badge */
}

/* When the notification count is > 0, show the badge */
.notification-container .notification-badge {
    display: inline-flex;
    justify-content: center;
    align-items: center;
}

.notification-container:hover .notification-badge {
    display: inline-flex; /* Show badge on hover */
}



    </style>
</head>

<body>
@php
        $notifications = App\Models\Notification::where('user_id', auth()->id())
            ->where('is_read', false)
            ->orderBy('created_at', 'desc')
            ->get();
    @endphp

    <div class="container">
        <!-- Sidebar -->
    
        <div class="sidebar">
            <h2>Logo</h2>
            <ul id="menu">
                <li><a href="/dashboard"><i class="fas fa-home"></i> Dashboard</a></li>
                <!-- <li id="users-menu"><a href="/users"><i class="fas fa-users"></i> Users</a></li>-->
                <li><a href="/tasks"><i class="fas fa-tasks"></i> Tasks</a></li>
                <li>
                    <a href="#" onclick="logout()">
                        <!--<i class="fas fa-sign-out-alt"></i> Logout -->
                    </a>
                </li>

            </ul>
        </div>

        <!-- Main Content -->
        <div class="main-content">
            <div class="header">
                <div class="header-left">
                    <h1>Welcome!</h1>
                    <h4 id="user_name"></h4>
                </div>
                <div class="header-right">
    <!-- Notification Icon with Badge -->
    <!-- Notification Bell -->
<div class="notification-container">
    <button id="notification-btn" class="p-2">
        <i class="fas fa-bell text-gray-600 text-xl notification-icon"></i>
        <span id="notification-count" class="notification-badge">
            0
        </span>
    </button>
</div>


    <!-- Message Icon (unchanged) -->
    <img src="{{ asset('images/chat.png') }}" alt="Messages" />

    <!-- Profile Dropdown -->
    <div class="profile-dropdown">
        <img src="{{ asset('images/group.png') }}" alt="Profile Icon" class="profile-icon" onclick="toggleProfileMenu()" />
        <div id="profileMenu" class="dropdown-content">
            <a href="/users"><i class="fas fa-user"></i> Profile</a>
            <a href="#" onclick="logout()"><i class="fas fa-sign-out-alt"></i> Logout</a>
        </div>
    </div>
</div>
</div>
<main>
@yield('content')  <!-- This is where the content of each page will go -->
</main>        
</div>
    </div>
</body>
</html>