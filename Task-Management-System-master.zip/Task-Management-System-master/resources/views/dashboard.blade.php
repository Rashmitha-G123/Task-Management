@extends('layout')

@section('title', 'Dashboard')

@section('header-title', 'Dashboard')

@section('content')
            <!-- Stats Cards -->
            <div class="stats-cards">
                <div class="card">
                    <div class="card-content">
                        <h3>Total Users</h3>
                        <span id="total-users">0</span>
                    </div>
                    <img src="{{asset('images/group.png')}}" alt="Users Icon" />
                </div>
                <div class="card">
                    <div class="card-content">
                        <h3>Total Tasks</h3>
                        <span id="total-tasks">0</span>
                    </div>
                    <img src="{{asset('images/ads_click.png')}}" alt="Tasks Icon" />
                </div>
                <div class="card">
                    <div class="card-content">
                        <h3>Completed Tasks</h3>
                        <span id="completed-tasks">0</span>
                    </div>
                    <img src="{{asset('images/handshake.png')}}" alt="Completed Tasks Icon" />
                </div>
            </div>
        </div>
    </div>
    @endsection


    <script>
        document.addEventListener('DOMContentLoaded', function () {
            displayMenuBasedOnRole();
            fetchNotifications()
            checkNotifications(); // Call function on page load
        setInterval(checkNotifications, 5000); 
            
        });

        // Display Menu Based on Role (Admin or User)
        function displayMenuBasedOnRole() {
            const role = localStorage.getItem('role');

            document.getElementById('user_name').textContent = localStorage.getItem('role');
            if (role === 'user') {
                document.getElementById('users-menu').style.display = 'none';
                fetchStatisticsUser();
            }else{
                fetchStatistics();
            }
        }

        // Fetch and Display Statistics
        function fetchStatistics() {
            const token = localStorage.getItem('token');

            fetch('http://127.0.0.1:8000/api/admin/statistics', {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${token}`
                },
            })
                .then(response => {
                    if (!response.ok) {
                        throw new Error('Network response was not ok');
                    }
                    return response.json();
                })
                .then(data => {
                    document.getElementById('total-users').textContent = data.total_users;
                    document.getElementById('total-tasks').textContent = data.total_tasks;
                    document.getElementById('completed-tasks').textContent = data.completed_tasks;
                })
                .catch(error => {
                    console.error('Error:', error);
                });
        }

        function fetchStatisticsUser() {
            const token = localStorage.getItem('token');
            const id = localStorage.getItem('u_id');
            fetch(`http://127.0.0.1:8000/api/user/getStatisticsUser/${id}`, {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${token}`
                },
            })
                .then(response => {
                    if (!response.ok) {
                        throw new Error('Network response was not ok');
                    }
                    return response.json();
                })
                .then(data => {
                    document.getElementById('total-users').textContent = data.total_users;
                    document.getElementById('total-tasks').textContent = "Total Task"+"("+data.total_tasks+")";
                    document.getElementById('completed-tasks').textContent = "Completed"+"("+data.completed_tasks+")";
                })
                .catch(error => {
                    console.error('Error:', error);
                });
        }
        function fetchNotifications() {
    fetch("/api/notifications") // Adjust this API route as per your backend setup
        .then(response => response.json())
        .then(data => {
            let notificationBadge = document.getElementById("notificationBadge");
            let notificationList = document.getElementById("notificationList");
            notificationList.innerHTML = "";

            if (data.length > 0) {
                notificationBadge.innerText = data.length;
                notificationBadge.style.display = "inline-block";
                
                data.forEach(notification => {
                    let listItem = document.createElement("li");
                    listItem.innerText = notification.message;
                    notificationList.appendChild(listItem);
                });
            } else {
                notificationBadge.style.display = "none";
                notificationList.innerHTML = "<li>No new notifications</li>";
            }
        })
        .catch(error => console.error("Error fetching notifications:", error));
}

// Fetch notifications every 10 seconds
setInterval(fetchNotifications, 10000);
fetchNotifications();


        function logout() {
            const token = localStorage.getItem('token');
    
            fetch('http://127.0.0.1:8000/api/logout', {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${token}`,
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content'),
                },
            })
            .then(response => {
                if (response.ok) {
                    localStorage.removeItem('token');  // Clear the token from storage
                    window.location.href = '/login';   // Redirect to login page
                }
            })
            .catch(error => console.error('Logout failed:', error));
        }
        function toggleProfileMenu() {
    let menu = document.getElementById("profileMenu");
    menu.style.display = menu.style.display === "block" ? "none" : "block";
}

// Close dropdown when clicking outside
document.addEventListener("click", function(event) {
    let profileMenu = document.getElementById("profileMenu");
    let profileIcon = document.querySelector(".profile-icon");

    // Check if click is outside profile dropdown
    if (profileMenu.style.display === "block" && !profileIcon.contains(event.target) && !profileMenu.contains(event.target)) {
        profileMenu.style.display = "none";
    }
});
function checkNotifications() {
        const token = localStorage.getItem('token');

        fetch('http://127.0.0.1:8000/api/notifications', {
            method: 'GET',
            headers: {
                'Authorization': `Bearer ${token}`,
                'Content-Type': 'application/json'
            },
        })
        .then(response => response.json())
        .then(data => {
            const notificationIcon = document.getElementById("notification-badge");
            if (data.unread_notifications > 0) {
                notificationIcon.style.display = "block";  // Show notification badge
                notificationIcon.textContent = data.unread_notifications;
            } else {
                notificationIcon.style.display = "none"; // Hide if no new notifications
            }
        })
        .catch(error => console.error("Error fetching notifications:", error));
    }
    document.querySelector('.notification img').addEventListener('click', function () {
    fetch('http://127.0.0.1:8000/api/mark-notifications-read', {
        method: 'POST',
        headers: {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json'
        },
    })
    .then(response => response.json())
    .then(() => {
        document.getElementById("notification-badge").style.display = "none";
    });
});
document.getElementById("notification-icon").addEventListener('click', function () {
        const token = localStorage.getItem('token'); // Ensure token is retrieved correctly

        fetch('http://127.0.0.1:8000/api/mark-notifications-read', {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${token}`,
                'Content-Type': 'application/json'
            },
        })
        .then(response => response.json())
        .then(() => {
            document.getElementById("notification-badge").style.display = "none"; // Hide badge
        })
        .catch(error => console.error("Error marking notifications as read:", error));
    });

    document.addEventListener("DOMContentLoaded", function () {
        const notificationBtn = document.getElementById("notification-btn");
        const notificationDropdown = document.getElementById("notification-dropdown");
        const notificationList = document.getElementById("notification-list");
        const notificationCount = document.getElementById("notification-count");

        notificationBtn.addEventListener("click", function () {
            fetchNotifications();
            fetch("/notifications/read", { method: "POST" });
            notificationDropdown.classList.toggle("hidden");
        });

        function fetchNotifications() {
            fetch("/notifications")
                .then(response => response.json())
                .then(data => {
                    notificationList.innerHTML = ""; // Clear old notifications
                    if (data.length > 0) {
                        data.forEach(notification => {
                            let listItem = document.createElement("div");
                            listItem.className = "p-2 border-b";
                            listItem.innerHTML = notification.data.message;
                            notificationList.appendChild(listItem);
                        });
                        notificationCount.innerText = data.length;
                        notificationCount.classList.remove("hidden");
                    } else {
                        notificationList.innerHTML = "<p class='p-2 text-gray-500'>No new notifications.</p>";
                        notificationCount.classList.add("hidden");
                    }
                })
                .catch(error => console.error("Error fetching notifications:", error));
        }
    });
    let notifications = [
        { id: 1, message: "New task assigned to you", timestamp: "2025-02-28 12:30 PM" },
        { id: 2, message: "Task completed", timestamp: "2025-02-27 10:15 AM" },
        { id: 3, message: "New comment on your task", timestamp: "2025-02-26 03:20 PM" }
    ];

    // Update notification count and show dropdown with details
    function updateNotifications() {
        let notificationCount = notifications.length;
        let notificationBadge = document.getElementById("notification-count");
        notificationBadge.textContent = notificationCount;
        
        let notificationDropdown = document.getElementById("notificationDropdown");
        notificationDropdown.innerHTML = notifications.map(notification => {
            return `<a href="#" class="dropdown-item">
                        <div class="notification-message">${notification.message}</div>
                        <small class="timestamp">${notification.timestamp}</small>
                    </a>`;
        }).join('');
        
        // Show notification badge if count > 0
        if (notificationCount > 0) {
            notificationBadge.style.display = 'inline-flex';
        } else {
            notificationBadge.style.display = 'none';
        }
    }
    function toggleNotificationDropdown() {
        let notificationDropdown = document.getElementById("notificationDropdown");
        notificationDropdown.classList.toggle("show");
    }

    // On page load, update notifications
    window.onload = function() {
        updateNotifications();
    }
async function loadNotifications() {
    try {
        let response = await fetch("{{ route('notifications.get') }}");
        let notifications = await response.json();
        let notificationList = document.getElementById("notification-list");
        let notificationCount = document.getElementById("notification-count");

        notificationList.innerHTML = "";

        notifications.forEach(notification => {
            let item = document.createElement("div");
            item.classList.add("p-2", "border-b");
            item.innerText = notification.data.message;
            notificationList.appendChild(item);
        });

        notificationCount.innerText = notifications.length;
        notificationCount.classList.toggle("hidden", notifications.length === 0);
    } catch (error) {
        console.error("Error fetching notifications:", error);
    }
}





    </script>
   
</body>
</html>
